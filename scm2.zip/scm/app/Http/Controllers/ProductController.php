<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Product::with(['category','unit'])->latest()->get();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //  ['name','category_id','unit_id','price','quantity','stock','description'];
        $data = $request->validate([
            'name'=>'required',
            'category_id'=>'required',
            'unit_id'=>'required',
            'price'=>'required',
            'quantity'=>'required',
            'description'=>'required',
        ]);


        if($request->file('image')){
            $file= $request->file('image');
            $filename= date('YmdHi').$file->getClientOriginalName();
            $file-> move(public_path('Image'), $filename);
            $data['image']= $filename;
        }
        $product = Product::create($data);

        return $product->load(['category','unit']);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Product::find($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name'=>'required',
            'category_id'=>'required',
            'unit_id'=>'required',
            'price'=>'required',
            'quantity'=>'required',
            'description'=>'required',
        ]);
        
        $product = Product::find($id);
        $product->update($request->all());
        return $product;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return Product::destroy($id);
    }

    public function stock_update(Request $request){
        if ($request->products) {
            //  $invoice->invoice_products()->sync($request->invoice_products);
            foreach ($request->products as $data) {
              // Increase Item quantinty
               $product = Product::find($data['product_id']);
               $product->quantity += $data['quantity'];
               $product->update();
            }
        }
     return 'Updated successfully';
    }
}
