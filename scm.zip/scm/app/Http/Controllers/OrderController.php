<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return Order::with(['order_items.product.unit','order_items.product.category'])->latest()->get();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         //validate
       $order = Order::create($request->all());
       if ($request->order_items) {
           //  $invoice->invoice_products()->sync($request->invoice_products);
           foreach ($request->order_items as $data) {
              $orderItem = OrderItem::create(
                  [
                      'order_id'=>$order->id,
                      'product_id'=>$data['product_id'],
                      'quantity'=>$data['quantity'],
                  ]
                  );
              // Decrease Item quantinty
            //   $product = Product::find($data['product_id']);
            //   $product->quantity -= $data['quantity'];
            //   $product->update();
           }
       }
       return $order;

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //update order
        $order = Order::find($id);
        $order->update(['status'=>1,'approved'=>1]);
        return $order;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
